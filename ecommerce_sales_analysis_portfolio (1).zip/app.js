document.addEventListener('DOMContentLoaded', function () {

  // Initialize Lucide Icons
  lucide.createIcons();

  // Theme Toggle Logic
  const themeToggle = document.getElementById('themeToggle');
  const sunIcon = document.getElementById('sunIcon');
  const moonIcon = document.getElementById('moonIcon');

  themeToggle.addEventListener('click', () => {
    const isDark = document.documentElement.classList.toggle('dark');
    if (isDark) {
      sunIcon.classList.remove('hidden');
      moonIcon.classList.add('hidden');
    } else {
      sunIcon.classList.add('hidden');
      moonIcon.classList.remove('hidden');
    }
    // Re-render charts to adjust text color for theme
    renderCharts();
  });

  // State Management
  let activeTab = 'dashboard';
  let currentPage = 1;
  const rowsPerPage = 12;
  let filteredSales = [...SALES_DATA];

  // Filters
  const regionFilter = document.getElementById('regionFilter');
  const segmentFilter = document.getElementById('segmentFilter');
  const tableSearch = document.getElementById('tableSearch');

  // Chart instances
  let revenueChartInstance = null;
  let categoryChartInstance = null;
  let regionalChartInstance = null;
  let segmentChartInstance = null;

  // Tab switching logic
  const tabs = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => {
        t.classList.remove('text-indigo-600', 'bg-indigo-50', 'dark:text-indigo-400', 'dark:bg-indigo-950/50');
        t.classList.add('text-slate-600', 'hover:text-slate-900', 'hover:bg-slate-50', 'dark:text-slate-400', 'dark:hover:text-slate-200', 'dark:hover:bg-slate-800/50');
      });
      tab.classList.add('text-indigo-600', 'bg-indigo-50', 'dark:text-indigo-400', 'dark:bg-indigo-950/50');
      tab.classList.remove('text-slate-600', 'hover:text-slate-900', 'hover:bg-slate-50', 'dark:text-slate-400', 'dark:hover:text-slate-200');

      const targetPane = tab.getAttribute('data-tab');
      tabPanes.forEach(pane => {
        if (pane.id === `tab-${targetPane}`) {
          pane.classList.remove('hidden');
        } else {
          pane.classList.add('hidden');
        }
      });

      activeTab = targetPane;
      if (activeTab === 'dashboard') {
        renderCharts();
      }
    });
  });

  // KPI & Analytics calculations
  function applyFilters() {
    const regionVal = regionFilter.value;
    const segmentVal = segmentFilter.value;

    filteredSales = SALES_DATA.filter(row => {
      const matchRegion = regionVal === 'All' || row['Region'] === regionVal;
      const matchSegment = segmentVal === 'All' || row['Segment'] === segmentVal;
      return matchRegion && matchSegment;
    });

    calculateKPIs();
    renderCharts();
  }

  function calculateKPIs() {
    let totalRev = 0;
    let totalCost = 0;
    let totalQty = 0;

    filteredSales.forEach(row => {
      totalRev += row['Revenue'];
      totalCost += row['Cost'];
      totalQty += row['Quantity'];
    });

    const profit = totalRev - totalCost;
    const margin = totalRev > 0 ? (profit / totalRev) * 100 : 0;
    const aov = filteredSales.length > 0 ? totalRev / filteredSales.length : 0;

    // Display formatted
    document.getElementById('kpi-revenue').innerText = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(totalRev);
    document.getElementById('kpi-profit').innerText = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(profit);
    document.getElementById('kpi-margin').innerText = margin.toFixed(1) + '%';
    document.getElementById('kpi-aov').innerText = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(aov);
  }

  // Visualizations logic
  function renderCharts() {
    const isDark = document.documentElement.classList.contains('dark');
    const textThemeColor = isDark ? '#cbd5e1' : '#475569';
    const gridThemeColor = isDark ? '#334155' : '#f1f5f9';

    // Grouping by Month for Monthly Revenue Trend
    // Format Month Date
    const monthlyData = {};
    filteredSales.forEach(row => {
      const d = new Date(row['Order Date']);
      const monthKey = d.toLocaleString('default', { month: 'short', year: 'numeric' });
      monthlyData[monthKey] = (monthlyData[monthKey] || 0) + row['Revenue'];
    });

    const monthLabels = Object.keys(monthlyData);
    const monthRevenues = Object.values(monthlyData);

    // Grouping by Category for Categories Chart
    const catData = {};
    const catProfitData = {};
    filteredSales.forEach(row => {
      const cat = row['Product Category'];
      catData[cat] = (catData[cat] || 0) + row['Revenue'];
      catProfitData[cat] = (catProfitData[cat] || 0) + row['Profit'];
    });

    const catLabels = Object.keys(catData);
    const catRevenues = Object.values(catData);
    const catProfits = Object.values(catProfitData);

    // Grouping by Region for Doughnut Chart
    const regData = {};
    filteredSales.forEach(row => {
      const reg = row['Region'];
      regData[reg] = (regData[reg] || 0) + row['Revenue'];
    });
    const regLabels = Object.keys(regData);
    const regRevenues = Object.values(regData);

    // Grouping by Segment
    const segData = {};
    filteredSales.forEach(row => {
      const seg = row['Segment'];
      segData[seg] = (segData[seg] || 0) + row['Revenue'];
    });
    const segLabels = Object.keys(segData);
    const segRevenues = Object.values(segData);

    // Render / Update Chart 1: Revenue Monthly Trend
    if (revenueChartInstance) revenueChartInstance.destroy();
    revenueChartInstance = new Chart(document.getElementById('revenueTrendChart'), {
      type: 'line',
      data: {
        labels: monthLabels,
        datasets: [{
          label: 'Monthly Revenue',
          data: monthRevenues,
          borderColor: '#4f46e5',
          backgroundColor: 'rgba(79, 70, 229, 0.05)',
          fill: true,
          tension: 0.3,
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: { ticks: { color: textThemeColor }, grid: { display: false } },
          y: { 
            ticks: { 
              color: textThemeColor,
              callback: function(value) { return '$' + (value / 1000) + 'k'; }
            },
            grid: { color: gridThemeColor }
          }
        }
      }
    });

    // Chart 2: Category Breakdown
    if (categoryChartInstance) categoryChartInstance.destroy();
    categoryChartInstance = new Chart(document.getElementById('categoryChart'), {
      type: 'bar',
      data: {
        labels: catLabels,
        datasets: [
          {
            label: 'Revenue',
            data: catRevenues,
            backgroundColor: '#6366f1',
            borderRadius: 6
          },
          {
            label: 'Net Profit',
            data: catProfits,
            backgroundColor: '#10b981',
            borderRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: { color: textThemeColor, boxWidth: 12, font: { size: 10 } }
          }
        },
        scales: {
          x: { ticks: { color: textThemeColor }, grid: { display: false } },
          y: { 
            ticks: { 
              color: textThemeColor,
              callback: function(value) { return '$' + (value / 1000) + 'k'; }
            },
            grid: { color: gridThemeColor }
          }
        }
      }
    });

    // Chart 3: Regional Comparison
    if (regionalChartInstance) regionalChartInstance.destroy();
    regionalChartInstance = new Chart(document.getElementById('regionalChart'), {
      type: 'doughnut',
      data: {
        labels: regLabels,
        datasets: [{
          data: regRevenues,
          backgroundColor: ['#4f46e5', '#3b82f6', '#10b981', '#f59e0b', '#ec4899']
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { color: textThemeColor, boxWidth: 10, font: { size: 10 } }
          }
        }
      }
    });

    // Chart 4: Segment Share
    if (segmentChartInstance) segmentChartInstance.destroy();
    segmentChartInstance = new Chart(document.getElementById('segmentChart'), {
      type: 'pie',
      data: {
        labels: segLabels,
        datasets: [{
          data: segRevenues,
          backgroundColor: ['#6366f1', '#14b8a6', '#f59e0b']
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { color: textThemeColor, boxWidth: 10, font: { size: 10 } }
          }
        }
      }
    });
  }

  // Interactive Table Exploration Logic
  function getFilteredTableData() {
    const q = tableSearch.value.toLowerCase();
    return SALES_DATA.filter(row => {
      return (
        row['Order ID'].toLowerCase().includes(q) ||
        row['Product Name'].toLowerCase().includes(q) ||
        row['Region'].toLowerCase().includes(q) ||
        row['Product Category'].toLowerCase().includes(q)
      );
    });
  }

  function renderTable() {
    const tblBody = document.getElementById('rawTableBody');
    const tableData = getFilteredTableData();

    // Pagination slicing
    const startIdx = (currentPage - 1) * rowsPerPage;
    const endIdx = startIdx + rowsPerPage;
    const paginatedData = tableData.slice(startIdx, endIdx);

    tblBody.innerHTML = '';

    if (paginatedData.length === 0) {
      tblBody.innerHTML = `<tr><td colspan="9" class="p-6 text-center text-slate-500 font-medium">No transactions match your search query.</td></tr>`;
      document.getElementById('tableInfo').innerText = 'Showing 0 to 0 of 0 entries';
      document.getElementById('prevPage').disabled = true;
      document.getElementById('nextPage').disabled = true;
      return;
    }

    paginatedData.forEach(row => {
      const tr = document.createElement('tr');
      tr.className = 'hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors duration-150';
      tr.innerHTML = `
        <td class="p-3 font-semibold text-slate-800 dark:text-slate-300">${row['Order ID']}</td>
        <td class="p-3">${row['Order Date']}</td>
        <td class="p-3">${row['Region']}</td>
        <td class="p-3"><span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">${row['Product Category']}</span></td>
        <td class="p-3 font-medium text-slate-700 dark:text-slate-300">${row['Product Name']}</td>
        <td class="p-3 text-right font-mono">$${row['Unit Price'].toFixed(2)}</td>
        <td class="p-3 text-right font-mono">${row['Quantity']}</td>
        <td class="p-3 text-right font-bold text-slate-900 dark:text-slate-100 font-mono">$${row['Revenue'].toFixed(2)}</td>
        <td class="p-3 text-right font-semibold text-emerald-600 dark:text-emerald-400 font-mono">$${row['Profit'].toFixed(2)}</td>
      `;
      tblBody.appendChild(tr);
    });

    // Pagination controls state
    const totalEntries = tableData.length;
    const showingTo = Math.min(endIdx, totalEntries);
    document.getElementById('tableInfo').innerText = `Showing ${startIdx + 1} to ${showingTo} of ${totalEntries} entries`;

    document.getElementById('prevPage').disabled = currentPage === 1;
    document.getElementById('nextPage').disabled = endIdx >= totalEntries;
  }

  // Event Listeners for Filters & Table pagination
  regionFilter.addEventListener('change', applyFilters);
  segmentFilter.addEventListener('change', applyFilters);

  tableSearch.addEventListener('input', () => {
    currentPage = 1; // Reset to page 1 on typing search
    renderTable();
  });

  document.getElementById('prevPage').addEventListener('click', () => {
    if (currentPage > 1) {
      currentPage--;
      renderTable();
    }
  });

  document.getElementById('nextPage').addEventListener('click', () => {
    const tableData = getFilteredTableData();
    if (currentPage * rowsPerPage < tableData.length) {
      currentPage++;
      renderTable();
    }
  });

  // Init Calls
  calculateKPIs();
  renderCharts();
  renderTable();
});
